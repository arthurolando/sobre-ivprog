import EN from './en';
import PT from './pt';
import ES from './es';

export default {
  'en': EN,
  'pt': PT,
  'es': ES
}
