import errors from './error.json';
import messages from './message.json'
import ui from './ui.json';

export default {
 'message' : messages,
 'error': errors,
 'ui': ui
}
