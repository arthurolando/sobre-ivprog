export class Input {

  requestInput (callback) {
    throw new Error("Must be implemented");
  }
}