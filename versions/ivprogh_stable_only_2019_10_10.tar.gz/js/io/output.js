export class Output {

  sendOutput (text) {
    throw new Error("Must be implemented");
  }
}