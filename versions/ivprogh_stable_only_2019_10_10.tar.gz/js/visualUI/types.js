export const Types = Object.freeze({
  INTEGER: "integer",
  REAL: "real",
  TEXT: "text",
  BOOLEAN: "boolean",
  VOID: "void"
});