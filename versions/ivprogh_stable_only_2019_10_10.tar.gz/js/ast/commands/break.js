import { Command } from './command';

export class Break extends Command {

  constructor () {
    super();
  }
}
