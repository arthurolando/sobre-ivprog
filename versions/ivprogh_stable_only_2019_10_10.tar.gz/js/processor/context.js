export const Context = Object.freeze({
  BASE: Symbol('context:base'),
  BREAKABLE: Symbol('context:breakable'),
  FUNCTION: Symbol('context:function')
});